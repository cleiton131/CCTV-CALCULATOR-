INSTRUÇÕES PARA PUBLICAR NO GITHUB PAGES:

1. Acesse: https://github.com/new
2. Crie um repositório público com o nome que desejar (ex: simulador-cctv)
3. Faça upload dos arquivos deste ZIP: index.html e logo.png
4. Vá até "Settings" > "Pages"
5. Em "Source", selecione "main" e a pasta / (root), depois clique em Save
6. O GitHub fornecerá o link do seu site, ex:
   https://seu-usuario.github.io/simulador-cctv/
